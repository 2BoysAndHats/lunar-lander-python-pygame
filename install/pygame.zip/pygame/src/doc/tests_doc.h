/* Auto generated file: with makeref.py .  Docs go in src/ *.doc . */
#define DOC_PYGAMETESTS "Pygame unit test suite package"

#define DOC_PYGAMETESTSRUN "run(*args, **kwds) -> tuple\nRun the Pygame unit test suite"



/* Docs in a comment... slightly easier to read. */

/*

pygame.tests
Pygame unit test suite package

pygame.tests.run
 run(*args, **kwds) -> tuple
Run the Pygame unit test suite

*/